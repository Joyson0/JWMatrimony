import React from 'react'

function DashboardPage() {
  return (
    <div className='text-3xl font-bold underline'>
      Dashboard
    </div>
  )
}

export default DashboardPage
